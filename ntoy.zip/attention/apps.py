from django.apps import AppConfig


class AttantionConfig(AppConfig):
    name = 'attantion'

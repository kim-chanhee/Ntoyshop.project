from django.apps import AppConfig


class BrowseConfig(AppConfig):
    name = 'browse'
